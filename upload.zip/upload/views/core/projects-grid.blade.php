@extends('layouts.master')
@section('title') @lang('translation.Projects_Grid') @endsection
@section('content')


@section('pagetitle')Projects Grid @endsection


    <div class="row">
        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="avatar">
                            <span class="avatar-title rounded bg-light text-danger font-size-16">
                                <img src="{{ URL::asset('assets/images/companies/img-1.png') }}" alt="" height="30">
                            </span>
                        </div>
                        <div class="ms-auto">
                            <div class="dropdown float-end">
                                <a class="text-muted dropdown-toggle font-size-18" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-haspopup="true">
                                    <i class="bx bx-dots-horizontal-rounded"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a class="dropdown-item" href="#">Edit</a>
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex-grow-1 mt-4">
                        <h5 class="text-truncate font-size-15"><a href="javascript: void(0);" class="text-dark">New
                                admin Design</a></h5>
                        <p class="text-muted mb-0">It will be as simple as Occidental</p>

                        <div class="mt-3 mb-1">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 87%"
                                            aria-valuenow="87" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <h6 class="mb-0 font-size-13"> 87%</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="px-4 py-2 border-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item me-3">
                                <i class="bx bx-paperclip me-1 font-size-16 align-middle"></i> 236
                            </li>
                            <li class="list-inline-item me-3">
                                <i class="bx bx-chat me-1 font-size-16 align-middle"></i> 202
                            </li>
                        </ul>

                        <div class="avatar-group">
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-4.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-5.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <div class="avatar-sm">
                                        <span class="avatar-title rounded-circle bg-success text-white font-size-16">
                                            A
                                        </span>
                                    </div>
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-2.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="avatar">
                            <span class="avatar-title rounded bg-light text-danger font-size-16">
                                <img src="{{ URL::asset('assets/images/companies/img-2.png') }}" alt="" height="30">
                            </span>
                        </div>
                        <div class="ms-auto">
                            <div class="dropdown float-end">
                                <a class="text-muted dropdown-toggle font-size-18" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-haspopup="true">
                                    <i class="bx bx-dots-horizontal-rounded"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a class="dropdown-item" href="#">Edit</a>
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex-grow-1 mt-4">
                        <h5 class="text-truncate font-size-15"><a href="javascript: void(0);" class="text-dark">Brand
                                logo design</a></h5>
                        <p class="text-muted mb-0">To achieve it would be necessary</p>

                        <div class="mt-3 mb-1">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-primary" role="progressbar" style="width: 86%"
                                            aria-valuenow="86" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <h6 class="mb-0 font-size-13"> 86%</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="px-4 py-2 border-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item me-3">
                                <i class="bx bx-paperclip me-1 font-size-16 align-middle"></i> 45
                            </li>
                            <li class="list-inline-item me-3">
                                <i class="bx bx-chat me-1 font-size-16 align-middle"></i> 95
                            </li>
                        </ul>

                        <div class="avatar-group">
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-8.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-2.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="avatar">
                            <span class="avatar-title rounded bg-light text-danger font-size-16">
                                <img src="{{ URL::asset('assets/images/companies/img-3.png') }}" alt="" height="30">
                            </span>
                        </div>
                        <div class="ms-auto">
                            <div class="dropdown float-end">
                                <a class="text-muted dropdown-toggle font-size-18" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-haspopup="true">
                                    <i class="bx bx-dots-horizontal-rounded"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a class="dropdown-item" href="#">Edit</a>
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex-grow-1 mt-4">
                        <h5 class="text-truncate font-size-15"><a href="javascript: void(0);" class="text-dark">New
                                Landing Design</a></h5>
                        <p class="text-muted mb-0">For science, music, sport, etc</p>

                        <div class="mt-3 mb-1">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar" role="progressbar" style="width: 75%"
                                            aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <h6 class="mb-0 font-size-13"> 75%</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="px-4 py-2 border-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item me-3">
                                <i class="bx bx-paperclip me-1 font-size-16 align-middle"></i> 124
                            </li>
                            <li class="list-inline-item me-3">
                                <i class="bx bx-chat me-1 font-size-16 align-middle"></i> 325
                            </li>
                        </ul>

                        <div class="avatar-group">
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <div class="avatar-sm">
                                        <span class="avatar-title rounded-circle bg-info text-white font-size-16">
                                            K
                                        </span>
                                    </div>
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-2.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="avatar">
                            <span class="avatar-title rounded bg-light text-danger font-size-16">
                                <img src="{{ URL::asset('assets/images/companies/img-4.png') }}" alt="" height="30">
                            </span>
                        </div>
                        <div class="ms-auto">
                            <div class="dropdown float-end">
                                <a class="text-muted dropdown-toggle font-size-18" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-haspopup="true">
                                    <i class="bx bx-dots-horizontal-rounded"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a class="dropdown-item" href="#">Edit</a>
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex-grow-1 mt-4">
                        <h5 class="text-truncate font-size-15"><a href="javascript: void(0);"
                                class="text-dark">Redesign - Landing page</a></h5>
                        <p class="text-muted mb-0">If several languages coalesce</p>

                        <div class="mt-3 mb-1">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-danger" role="progressbar" style="width: 92%"
                                            aria-valuenow="92" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <h6 class="mb-0 font-size-13"> 92%</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="px-4 py-2 border-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item me-3">
                                <i class="bx bx-paperclip me-1 font-size-16 align-middle"></i> 225
                            </li>
                            <li class="list-inline-item me-3">
                                <i class="bx bx-chat me-1 font-size-16 align-middle"></i> 326
                            </li>
                        </ul>

                        <div class="avatar-group">
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-1.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-6.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-7.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="avatar">
                            <span class="avatar-title rounded bg-light text-danger font-size-16">
                                <img src="{{ URL::asset('assets/images/companies/img-5.png') }}" alt="" height="30">
                            </span>
                        </div>
                        <div class="ms-auto">
                            <div class="dropdown float-end">
                                <a class="text-muted dropdown-toggle font-size-18" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-haspopup="true">
                                    <i class="bx bx-dots-horizontal-rounded"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a class="dropdown-item" href="#">Edit</a>
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex-grow-1 mt-4">
                        <h5 class="text-truncate font-size-15"><a href="javascript: void(0);" class="text-dark">Borex
                                Dashboard UI</a></h5>
                        <p class="text-muted mb-0">Separate existence is a myth</p>

                        <div class="mt-3 mb-1">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar" role="progressbar" style="width: 75%"
                                            aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <h6 class="mb-0 font-size-13"> 75%</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="px-4 py-2 border-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item me-3">
                                <i class="bx bx-paperclip me-1 font-size-16 align-middle"></i> 321
                            </li>
                            <li class="list-inline-item me-3">
                                <i class="bx bx-chat me-1 font-size-16 align-middle"></i> 214
                            </li>
                        </ul>

                        <div class="avatar-group">
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-1.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-3.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <div class="avatar-sm">
                                        <span class="avatar-title rounded-circle bg-danger text-white font-size-16">
                                            3+
                                        </span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="avatar">
                            <span class="avatar-title rounded bg-light text-danger font-size-16">
                                <img src="{{ URL::asset('assets/images/companies/img-6.png') }}" alt="" height="30">
                            </span>
                        </div>
                        <div class="ms-auto">
                            <div class="dropdown float-end">
                                <a class="text-muted dropdown-toggle font-size-18" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-haspopup="true">
                                    <i class="bx bx-dots-horizontal-rounded"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a class="dropdown-item" href="#">Edit</a>
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex-grow-1 mt-4">
                        <h5 class="text-truncate font-size-15"><a href="javascript: void(0);" class="text-dark">Blog
                                Template UI</a></h5>
                        <p class="text-muted mb-0">For science, music, sport, etc</p>

                        <div class="mt-3 mb-1">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-danger" role="progressbar" style="width: 88%"
                                            aria-valuenow="88" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <h6 class="mb-0 font-size-13"> 88%</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="px-4 py-2 border-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item me-3">
                                <i class="bx bx-paperclip me-1 font-size-16 align-middle"></i> 125
                            </li>
                            <li class="list-inline-item me-3">
                                <i class="bx bx-chat me-1 font-size-16 align-middle"></i> 143
                            </li>
                        </ul>

                        <div class="avatar-group">
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-4.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-5.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="avatar">
                            <span class="avatar-title rounded bg-light text-danger font-size-16">
                                <img src="{{ URL::asset('assets/images/companies/img-4.png') }}" alt="" height="30">
                            </span>
                        </div>
                        <div class="ms-auto">
                            <div class="dropdown float-end">
                                <a class="text-muted dropdown-toggle font-size-18" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-haspopup="true">
                                    <i class="bx bx-dots-horizontal-rounded"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a class="dropdown-item" href="#">Edit</a>
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex-grow-1 mt-4">
                        <h5 class="text-truncate font-size-15"><a href="javascript: void(0);" class="text-dark">App
                                Landing UI</a></h5>
                        <p class="text-muted mb-0">To achieve it would be necessary</p>

                        <div class="mt-3 mb-1">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-primary" role="progressbar" style="width: 84%"
                                            aria-valuenow="84" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <h6 class="mb-0 font-size-13"> 84%</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="px-4 py-2 border-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item me-3">
                                <i class="bx bx-paperclip me-1 font-size-16 align-middle"></i> 241
                            </li>
                            <li class="list-inline-item me-3">
                                <i class="bx bx-chat me-1 font-size-16 align-middle"></i> 236
                            </li>
                        </ul>

                        <div class="avatar-group">
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <div class="avatar-sm">
                                        <span class="avatar-title rounded-circle bg-pink text-white font-size-16">
                                            L
                                        </span>
                                    </div>
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-2.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="avatar">
                            <span class="avatar-title rounded bg-light text-danger font-size-16">
                                <img src="{{ URL::asset('assets/images/companies/img-2.png') }}" alt="" height="30">
                            </span>
                        </div>
                        <div class="ms-auto">
                            <div class="dropdown float-end">
                                <a class="text-muted dropdown-toggle font-size-18" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-haspopup="true">
                                    <i class="bx bx-dots-horizontal-rounded"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a class="dropdown-item" href="#">Edit</a>
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex-grow-1 mt-4">
                        <h5 class="text-truncate font-size-15"><a href="javascript: void(0);" class="text-dark">New
                                admin Design</a></h5>
                        <p class="text-muted mb-0">Their most common words.</p>

                        <div class="mt-3 mb-1">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 62%"
                                            aria-valuenow="62" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <h6 class="mb-0 font-size-13"> 62%</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="px-4 py-2 border-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item me-3">
                                <i class="bx bx-paperclip me-1 font-size-16 align-middle"></i> 105
                            </li>
                            <li class="list-inline-item me-3">
                                <i class="bx bx-chat me-1 font-size-16 align-middle"></i> 235
                            </li>
                        </ul>

                        <div class="avatar-group">
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-4.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-5.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <div class="avatar-sm">
                                        <span class="avatar-title rounded-circle bg-success text-white font-size-16">
                                            A
                                        </span>
                                    </div>
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-2.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="avatar">
                            <span class="avatar-title rounded bg-light text-danger font-size-16">
                                <img src="{{ URL::asset('assets/images/companies/img-2.png') }}" alt="" height="30">
                            </span>
                        </div>
                        <div class="ms-auto">
                            <div class="dropdown float-end">
                                <a class="text-muted dropdown-toggle font-size-18" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-haspopup="true">
                                    <i class="bx bx-dots-horizontal-rounded"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a class="dropdown-item" href="#">Edit</a>
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex-grow-1 mt-4">
                        <h5 class="text-truncate font-size-15"><a href="javascript: void(0);" class="text-dark">Brand
                                logo design</a></h5>
                        <p class="text-muted mb-0">To achieve it would be necessary</p>

                        <div class="mt-3 mb-1">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-primary" role="progressbar" style="width: 86%"
                                            aria-valuenow="86" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <h6 class="mb-0 font-size-13"> 86%</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="px-4 py-2 border-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item me-3">
                                <i class="bx bx-paperclip me-1 font-size-16 align-middle"></i> 45
                            </li>
                            <li class="list-inline-item me-3">
                                <i class="bx bx-chat me-1 font-size-16 align-middle"></i> 95
                            </li>
                        </ul>

                        <div class="avatar-group">
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-8.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-2.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="avatar">
                            <span class="avatar-title rounded bg-light text-danger font-size-16">
                                <img src="{{ URL::asset('assets/images/companies/img-1.png') }}" alt="" height="30">
                            </span>
                        </div>
                        <div class="ms-auto">
                            <div class="dropdown float-end">
                                <a class="text-muted dropdown-toggle font-size-18" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-haspopup="true">
                                    <i class="bx bx-dots-horizontal-rounded"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a class="dropdown-item" href="#">Edit</a>
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex-grow-1 mt-4">
                        <h5 class="text-truncate font-size-15"><a href="javascript: void(0);" class="text-dark">New
                                admin Design</a></h5>
                        <p class="text-muted mb-0">It will be as simple as Occidental</p>

                        <div class="mt-3 mb-1">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 97%"
                                            aria-valuenow="97" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <h6 class="mb-0 font-size-13"> 97%</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="px-4 py-2 border-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item me-3">
                                <i class="bx bx-paperclip me-1 font-size-16 align-middle"></i> 236
                            </li>
                            <li class="list-inline-item me-3">
                                <i class="bx bx-chat me-1 font-size-16 align-middle"></i> 202
                            </li>
                        </ul>

                        <div class="avatar-group">
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-4.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-5.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <div class="avatar-sm">
                                        <span class="avatar-title rounded-circle bg-success text-white font-size-16">
                                            A
                                        </span>
                                    </div>
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-2.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="avatar">
                            <span class="avatar-title rounded bg-light text-danger font-size-16">
                                <img src="{{ URL::asset('assets/images/companies/img-3.png') }}" alt="" height="30">
                            </span>
                        </div>
                        <div class="ms-auto">
                            <div class="dropdown float-end">
                                <a class="text-muted dropdown-toggle font-size-18" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-haspopup="true">
                                    <i class="bx bx-dots-horizontal-rounded"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a class="dropdown-item" href="#">Edit</a>
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex-grow-1 mt-4">
                        <h5 class="text-truncate font-size-15"><a href="javascript: void(0);" class="text-dark">New
                                Landing Design</a></h5>
                        <p class="text-muted mb-0">For science, music, sport, etc</p>

                        <div class="mt-3 mb-1">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar" role="progressbar" style="width: 75%"
                                            aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <h6 class="mb-0 font-size-13"> 75%</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="px-4 py-2 border-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item me-3">
                                <i class="bx bx-paperclip me-1 font-size-16 align-middle"></i> 124
                            </li>
                            <li class="list-inline-item me-3">
                                <i class="bx bx-chat me-1 font-size-16 align-middle"></i> 325
                            </li>
                        </ul>

                        <div class="avatar-group">
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <div class="avatar-sm">
                                        <span class="avatar-title rounded-circle bg-info text-white font-size-16">
                                            K
                                        </span>
                                    </div>
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-2.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="avatar">
                            <span class="avatar-title rounded bg-light text-danger font-size-16">
                                <img src="{{ URL::asset('assets/images/companies/img-6.png') }}" alt="" height="30">
                            </span>
                        </div>
                        <div class="ms-auto">
                            <div class="dropdown float-end">
                                <a class="text-muted dropdown-toggle font-size-18" href="#" role="button"
                                    data-bs-toggle="dropdown" aria-haspopup="true">
                                    <i class="bx bx-dots-horizontal-rounded"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a class="dropdown-item" href="#">Edit</a>
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex-grow-1 mt-4">
                        <h5 class="text-truncate font-size-15"><a href="javascript: void(0);" class="text-dark">Blog
                                Template UI</a></h5>
                        <p class="text-muted mb-0">For science, music, sport, etc</p>

                        <div class="mt-3 mb-1">
                            <div class="row align-items-center">
                                <div class="col">
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-danger" role="progressbar" style="width: 88%"
                                            aria-valuenow="88" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <h6 class="mb-0 font-size-13"> 88%</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="px-4 py-2 border-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <ul class="list-inline mb-0">
                            <li class="list-inline-item me-3">
                                <i class="bx bx-paperclip me-1 font-size-16 align-middle"></i> 125
                            </li>
                            <li class="list-inline-item me-3">
                                <i class="bx bx-chat me-1 font-size-16 align-middle"></i> 143
                            </li>
                        </ul>

                        <div class="avatar-group">
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-4.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                            <div class="avatar-group-item">
                                <a href="javascript: void(0);" class="d-inline-block">
                                    <img src="{{ URL::asset('assets/images/users/avatar-5.jpg') }}" alt="" class="rounded-circle avatar-sm">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- end row -->

    <div class="row">
        <div class="col-lg-12">
            <ul class="pagination pagination-rounded justify-content-end mt-2 mb-5">
                <li class="page-item disabled">
                    <a href="javascript: void(0);" class="page-link"><i class="mdi mdi-chevron-left"></i></a>
                </li>
                <li class="page-item active">
                    <a href="javascript: void(0);" class="page-link">1</a>
                </li>
                <li class="page-item">
                    <a href="javascript: void(0);" class="page-link">2</a>
                </li>
                <li class="page-item">
                    <a href="javascript: void(0);" class="page-link">3</a>
                </li>
                <li class="page-item">
                    <a href="javascript: void(0);" class="page-link">4</a>
                </li>
                <li class="page-item">
                    <a href="javascript: void(0);" class="page-link">5</a>
                </li>
                <li class="page-item">
                    <a href="javascript: void(0);" class="page-link"><i class="mdi mdi-chevron-right"></i></a>
                </li>
            </ul>
        </div>
    </div>
    <!-- end row -->

@endsection
@section('script')
    <script src="{{ URL::asset('/assets/js/app.min.js') }}"></script>
@endsection
