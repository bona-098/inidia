<!-- JAVASCRIPT -->
<script src="{{ URL::asset('assets/libs/bootstrap/bootstrap.min.js') }}"></script>
<script src="{{ URL::asset('assets/libs/metismenu/metismenu.min.js') }}"></script>
<script src="{{ URL::asset('assets/libs/simplebar/simplebar.min.js') }}"></script>
<script src="{{ URL::asset('assets/libs/eva-icons/eva-icons.min.js') }}"></script>
<script src="{{ URL::asset('assets/libs/moment/moment.min.js') }}"></script>
<script src="{{ URL::asset('assets/libs/sweetalert2/sweetalert2.min.js') }}"></script>
<script src="{{ URL::asset('/assets/js/app.min.js') }}"></script>

<script type="text/javascript" src="{{ asset('assets/js/jquery-3.5.1.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/jszip.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/dx-quill.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('assets/js/dx.all.js') }}"></script>

@yield('script')
@yield('script-bottom')
