<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LogSuccess extends Model
{
    protected $table = "_logsuccess";

    protected $guarded = ['id'];
}
