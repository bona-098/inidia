<?php

namespace App\Http\Controllers\Submission;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Mail;

use App\Models\Submission\Hrsc;
use App\Models\ApproverListReq;
use App\Models\ApproverListHistory;
use App\Models\Approvaluser;
use App\Models\Module;
use App\Models\Attachment;
use App\Models\User;
use App\Models\Assignmentto;
use DB;
use App\Mail\SubmissionMail;

class HrscReportController extends Controller
{
    public $model;
    public $modulename;
    public $module;

    public function __construct()
    {
        $this->model = new Hrsc();
        $this->modulename = 'Hrsc';
        $this->module = new Module();
    }

    public function index(Request $request)
    {
        try {
            
            $id = $request->id;
            $user_id = $this->getAuth()->id;
            $employeeid = $this->getEmployeeID()->id;
            $module_id = $this->getModuleId($this->modulename);
            $isAdmin = $this->getAuth()->isAdmin;
            $isDeveloper = $this->isDeveloper();

            $dataquery = $this->model->query();

            $subquery = "(select TOP 1 CASE WHEN a.user_id='".$user_id."' then 1 else 0 end 
            from tbl_approverListReq l
            left join tbl_approver a on l.approver_id=a.id
            left join tbl_approvaltype r on a.approvaltype_id = r.id 
            where l.ApprovalAction='1' and l.req_id = request_hrsc.id and l.module_id = '".$module_id."' and request_hrsc.requestStatus='1'
            order by a.sequence)";

            if(!$isAdmin) {
                $dataquery->selectRaw("CASE WHEN tbl_assignment.employee_id = '".$employeeid."' then 1 else 0 end as isPIC");
                $dataquery->leftJoin('tbl_assignment',function($join) use ( $user_id, $module_id){
                    $join->on('request_hrsc.id','=','tbl_assignment.req_id')
                        ->where("request_hrsc.user_id", "!=", $user_id)
                        ->where('tbl_assignment.module_id',$module_id);
                });
            }

            $data = $dataquery
                ->selectRaw("request_hrsc.*,codes.code,
                    CASE WHEN request_hrsc.user_id='".$user_id."' then 1 else 0 end as isMine,
                    ".$subquery." as isPendingOnMe
                ")
                ->leftJoin('codes','request_hrsc.code_id','codes.id')
                ->with(['user','approverlist'])
                ->where(function ($query) use ($subquery, $user_id, $isAdmin, $isDeveloper, $employeeid, $module_id) {
                    $query->whereRaw($subquery . " = 1")
                        ->orWhere(function ($query) use ($user_id, $isAdmin, $isDeveloper, $employeeid, $module_id) {
                            if ($isAdmin) {
                                $query->where("request_hrsc.user_id", "!=", $user_id)
                                    ->whereIn("request_hrsc.requestStatus", [1,3,4]);
                            }
                             else {
                                $query->where("tbl_assignment.employee_id",$employeeid)
                                    ->whereIn("request_hrsc.requestStatus", [3]);
                            }
                        })
                        ->orWhere("request_hrsc.user_id", $user_id);
                })
                ->orderBy(DB::raw($subquery), 'DESC')
                ->orderByRaw("CASE WHEN request_hrsc.user_id = '".$user_id."' THEN 0 ELSE 1 END, request_hrsc.created_at desc")
                ->get();

            return response()->json([
                'status' => "show",
                'message' => $this->getMessage()['show'],
                'data' => $data
            ])->setEncodingOptions(JSON_NUMERIC_CHECK);

        } catch (\Exception $e) {

            return response()->json(["status" => "error", "message" => $e->getMessage()]);
        }
    }

    public function store(Request $request)
    {
        //
    }

    public function show($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}