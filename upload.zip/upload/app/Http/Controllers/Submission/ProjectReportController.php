<?php

namespace App\Http\Controllers\Submission;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Submission\Project;
use App\Models\Module;
use App\Http\Traits\ProcessProjectTrait;

class ProjectReportController extends Controller
{
    use ProcessProjectTrait;
    
    public $model;
    public $modulename;
    public $module;

    public function __construct()
    {
        $this->model = new Project();
        $this->modulename = 'Project';
        $this->module = new Module();
    }
    
    public function index(Request $request)
    {
        try {
            
            $id = $request->id;
            $user_id = $this->getAuth()->id;
            $module_id = $this->getModuleId($this->modulename);

            $subquery = "(select TOP 1 CASE WHEN a.user_id='".$user_id."'  then 1 else 0 end 
            from tbl_approverListReq l
            left join tbl_approver a on l.approver_id=a.id
            left join tbl_approvaltype r on a.approvaltype_id = r.id 
            where l.ApprovalAction='1' and l.req_id = request_project.id and l.module_id = '".$module_id."' and request_project.requestStatus='1'
            order by a.sequence)";

            $data = $this->model
                ->selectRaw("request_project.*,codes.code,
                    CASE WHEN request_project.user_id='".$user_id."' then 1 else 0 end as isMine,
                    ".$subquery." as isPendingOnMe
                ")
                ->leftJoin('codes','request_project.code_id','codes.id')
                ->with(['user','approverlist'])
                ->where(function ($query) use ($subquery, $user_id) {
                    $query->whereRaw($subquery . " = 1")
                        ->orWhere(function ($query) use ($user_id) {
                            if ($this->getAuth()->isAdmin) {
                                $query->where("request_project.user_id", "!=", $user_id)
                                    ->whereIn("request_project.requestStatus", [1,3,4]);
                            } else {
                                $query->where("request_project.user_id", "!=", $user_id)
                                    ->whereIn("request_project.requestStatus", [3,4]);
                            }
                        })
                        ->orWhere("request_project.user_id", $user_id);
                })
                ->orderBy(DB::raw($subquery), 'DESC')
                ->orderByRaw("CASE WHEN request_project.user_id = '".$user_id."' THEN 0 ELSE 1 END, request_project.created_at desc")
                ->get();

            return response()->json([
                'status' => "show",
                'message' => $this->getMessage()['show'],
                'data' => $data
            ])->setEncodingOptions(JSON_NUMERIC_CHECK);

        } catch (\Exception $e) {

            return response()->json(["status" => "error", "message" => $e->getMessage()]);
        }
    }
    
    public function bird()
    {
        return view('dashboard.dashboardreport');
    }

    public function create()
    {
        //
    }

    
    public function store(Request $request)
    {
        //
    }

    
    public function show($id)
    {
        //
    }

    
    public function edit($id)
    {
        //
    }

    
    public function update(Request $request, $id)
    {
        //
    }

    
    public function destroy($id)
    {
        //
    }
}
